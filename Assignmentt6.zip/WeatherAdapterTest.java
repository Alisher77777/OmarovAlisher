class TestLibraryManagement {
    public static void main(String[] args) {
        LibraryFacade libraryFacade = new LibraryManagementFacade();

        libraryFacade.borrowBook("user123", "book456");

        libraryFacade.returnBook("user123", "book456");

        libraryFacade.searchBook("Harry Potter");

        System.out.println("Book availability: " + libraryFacade.checkAvailability("book456"));

        System.out.println("The teacher was amazed by the simplicity and effectiveness of the Library Management System Facade.");
    }
}
