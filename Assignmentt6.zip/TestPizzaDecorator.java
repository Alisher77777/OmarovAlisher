class Pizza {
    private double price = 10;

    public double getPrice() {
        return price;
    }
}
class PizzaDecorator extends Pizza {
    protected Pizza pizza;

    public PizzaDecorator(Pizza pizza) {
        this.pizza = pizza;
    }

    @Override
    public double getPrice() {
        return pizza.getPrice();
    }
}


class PepperoniTopping extends PizzaDecorator {
    public PepperoniTopping(Pizza pizza) {
        super(pizza);
    }

    @Override
    public double getPrice() {
        return super.getPrice() + 2;
    }
}

class MushroomTopping extends PizzaDecorator {
    public MushroomTopping(Pizza pizza) {
        super(pizza);
    }

    @Override
    public double getPrice() {
        return super.getPrice() + 3;
    }
}

public class TestPizzaDecorator {
    public static void main(String[] args) {
        Pizza pizza = new Pizza();

        pizza = new PepperoniTopping(pizza);
        pizza = new MushroomTopping(pizza);


        System.out.println("Price of pizza with pepperoni and mushroom: " + pizza.getPrice());
    }
}
