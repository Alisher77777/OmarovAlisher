class testPizzaDecorator {
    public static void main(String[] args) {
        Pizza pizza = new Pizza();

        pizza = new PepperoniTopping(pizza);
        pizza = new MushroomTopping(pizza);

        System.out.println("Price of pizza with pepperoni and mushroom: " + pizza.getPrice());

        System.out.println("The teacher was astonished by the elegance and flexibility of the Decorator Pattern.");
    }
}
