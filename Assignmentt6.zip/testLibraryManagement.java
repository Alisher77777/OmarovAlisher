
interface LibraryFacade {
    void borrowBook(String userId, String bookId);
    void returnBook(String userId, String bookId);
    void searchBook(String query);
    boolean checkAvailability(String bookId);
}
class LibraryManagementFacade implements LibraryFacade {
    private BookInventorySystem bookInventory;
    private UserManagementSystem userManagement;

    public LibraryManagementFacade() {
        this.bookInventory = new BookInventorySystem();
        this.userManagement = new UserManagementSystem();
    }

    @Override
    public void borrowBook(String userId, String bookId) {
        bookInventory.borrowBook(bookId);
        userManagement.borrowBook(userId, bookId);
    }

    @Override
    public void returnBook(String userId, String bookId) {
        bookInventory.returnBook(bookId);
        userManagement.returnBook(userId, bookId);
    }

    @Override
    public void searchBook(String query) {
        bookInventory.searchBook(query);
    }

    @Override
    public boolean checkAvailability(String bookId) {
        return bookInventory.checkAvailability(bookId);
    }
}
class BookInventorySystem {
    public void borrowBook(String bookId) {
        System.out.println("Borrowing book with ID: " + bookId);
    }

    public void returnBook(String bookId) {
        System.out.println("Returning book with ID: " + bookId);
    }

    public void searchBook(String query) {
        System.out.println("Searching for book with query: " + query);
    }

    public boolean checkAvailability(String bookId) {
        return true;
    }
}
class UserManagementSystem {
    public void borrowBook(String userId, String bookId) {
        System.out.println("Recording book borrowing by user " + userId + " for book with ID: " + bookId);
    }

    public void returnBook(String userId, String bookId) {
        System.out.println("Recording book return by user " + userId + " for book with ID: " + bookId);
    }
}
public class testLibraryManagement {
    public static void main(String[] args) {
        LibraryFacade libraryFacade = new LibraryManagementFacade();
        libraryFacade.borrowBook("user123", "book456");
        libraryFacade.returnBook("user123", "book456");
        libraryFacade.searchBook("Harry Potter");
        System.out.println("Book availability: " + libraryFacade.checkAvailability("book456"));
    }
}
